package tss2.wiki.control;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by 羊驼 on 2016/7/8.
 */
@Controller
@RequestMapping("")
public class ContentController {

}
